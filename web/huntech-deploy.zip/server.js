const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { spawn } = require('child_process');

const port = Number(process.env.PORT) || 8080;
const base = __dirname;

const mimeTypes = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
};

const server = http.createServer((req, res) => {
  if (req.url.startsWith('/proxy')) {
    const requestUrl = new URL(req.url, `http://${req.headers.host}`);
    const target = requestUrl.searchParams.get('url');

    if (!target) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Missing url');
      return;
    }

    let targetUrl;
    try {
      targetUrl = new URL(target);
    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Invalid url');
      return;
    }

    const allowedHosts = ['mdc.mo.gov', 'www.mdc.mo.gov', 'gisblue.mdc.mo.gov'];
    if (!allowedHosts.includes(targetUrl.hostname)) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Host not allowed');
      return;
    }

    https.get(targetUrl, (proxyRes) => {
      res.writeHead(proxyRes.statusCode || 200, {
        'Content-Type': proxyRes.headers['content-type'] || 'text/plain',
        'Access-Control-Allow-Origin': '*'
      });
      proxyRes.pipe(res);
    }).on('error', () => {
      res.writeHead(502, { 'Content-Type': 'text/plain' });
      res.end('Proxy request failed');
    });
    return;
  }

  let filePath = path.join(base, req.url === '/' ? 'index.html' : req.url);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
    res.end(data);
  });
});

server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);

  // Fire-and-forget local backup runner (chat logs + project files).
  try {
    const child = spawn(process.execPath, [path.join(__dirname, 'auto-chatlog-backup.js')], {
      stdio: 'ignore',
      detached: true,
      windowsHide: true
    });
    child.unref();
  } catch (error) {
    // Best-effort; server should still run.
  }
});

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$port = 8080
$url = "http://localhost:$port/"

try {
  Start-Process $url | Out-Null
  Write-Output "Opened $url"
} catch {
  Write-Output "Failed to open browser: $($_.Exception.Message)"
}

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = $MyInvocation.MyCommand.Path
$toolsDir = Split-Path -Parent $scriptPath
$root = Split-Path -Parent $toolsDir
$handoffScript = Join-Path $toolsDir "handoff.ps1"
$copyScript = Join-Path $toolsDir "handoff-copy.ps1"

if (-not (Test-Path $handoffScript)) {
  Write-Error "handoff.ps1 not found in tools folder."
  exit 1
}

$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = $root
$watcher.IncludeSubdirectories = $true
$watcher.EnableRaisingEvents = $true
$watcher.Filter = "*.*"

$extensions = @(".js", ".css", ".html", ".md", ".json")
$ignorePaths = @("\\backups\\", "\\node_modules\\", "\\.git\\")

$timer = New-Object System.Timers.Timer
$timer.Interval = 600
$timer.AutoReset = $false
$timer.Enabled = $false

$action = {
  foreach ($p in $ignorePaths) {
    if ($Event.SourceEventArgs.FullPath -like "*$p*") { return }
  }
  if ($extensions -notcontains [System.IO.Path]::GetExtension($Event.SourceEventArgs.FullPath)) { return }
  $timer.Stop()
  $timer.Start()
}

Register-ObjectEvent $watcher "Changed" -Action $action | Out-Null
Register-ObjectEvent $watcher "Created" -Action $action | Out-Null
Register-ObjectEvent $watcher "Deleted" -Action $action | Out-Null
Register-ObjectEvent $watcher "Renamed" -Action $action | Out-Null

Register-ObjectEvent $timer "Elapsed" -Action {
  try {
    powershell -ExecutionPolicy Bypass -File $handoffScript | Out-Null
    if (Test-Path $copyScript) {
      powershell -ExecutionPolicy Bypass -File $copyScript | Out-Null
    }
    Write-Output "Handoff updated: $((Get-Date).ToString("HH:mm:ss"))"
  } catch {
    Write-Output "Handoff update failed: $($_.Exception.Message)"
  }
} | Out-Null

Write-Output "Auto handoff watch is running. Press Ctrl+C to stop."
while ($true) { Start-Sleep -Seconds 1 }

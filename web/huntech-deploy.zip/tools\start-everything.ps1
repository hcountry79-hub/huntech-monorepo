Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = $MyInvocation.MyCommand.Path
$toolsDir = Split-Path -Parent $scriptPath
$root = Split-Path -Parent $toolsDir

$startServer = Join-Path $toolsDir "start-server.ps1"
$handoffWatch = Join-Path $toolsDir "handoff-watch.ps1"
$handoffGen = Join-Path $toolsDir "handoff.ps1"
$handoffCopy = Join-Path $toolsDir "handoff-copy.ps1"
$openBrowser = Join-Path $toolsDir "open-browser.ps1"

function Start-Background([string]$label, [string]$scriptPath) {
  if (-not (Test-Path $scriptPath)) {
    Write-Output "$label: script not found: $scriptPath"
    return
  }
  Start-Process -FilePath "powershell" -ArgumentList @(
    "-ExecutionPolicy", "Bypass",
    "-File", $scriptPath
  ) | Out-Null
  Write-Output "$label: started"
}

Write-Output "HUNTECH: starting everything..."

Start-Background "Dev Server" $startServer
Start-Background "Handoff Watch" $handoffWatch

if (Test-Path $handoffGen) {
  powershell -ExecutionPolicy Bypass -File $handoffGen | Out-Null
  Write-Output "Handoff: generated"
}

if (Test-Path $handoffCopy) {
  powershell -ExecutionPolicy Bypass -File $handoffCopy | Out-Null
  Write-Output "Handoff: copied to clipboard"
}

if (Test-Path $openBrowser) {
  powershell -ExecutionPolicy Bypass -File $openBrowser | Out-Null
}

Write-Output "HUNTECH: ready"

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = $MyInvocation.MyCommand.Path
$toolsDir = Split-Path -Parent $scriptPath
$root = Split-Path -Parent $toolsDir
$gitDir = Join-Path $root ".git"

if (-not (Test-Path $gitDir)) {
  Write-Output "No .git directory found. Initialize git to install hooks."
  exit 0
}

$hooksDir = Join-Path $gitDir "hooks"
if (-not (Test-Path $hooksDir)) {
  New-Item -ItemType Directory -Path $hooksDir | Out-Null
}

$hookPath = Join-Path $hooksDir "pre-commit"
$handoffPath = Join-Path $root "tools\handoff.ps1"
$hookContent = @"
#!/bin/sh
powershell -ExecutionPolicy Bypass -File "$handoffPath"
exit 0
"@

$hookContent | Set-Content -Path $hookPath -Encoding ASCII
Write-Output "Installed git pre-commit hook: $hookPath"

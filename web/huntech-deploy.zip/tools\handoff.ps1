Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = $MyInvocation.MyCommand.Path
$toolsDir = Split-Path -Parent $scriptPath
$root = Split-Path -Parent $toolsDir

$statePath = Join-Path $root "PROJECT_STATE.md"
$tasksPath = Join-Path $root "TASKS.md"
$changelogPath = Join-Path $root "CHANGELOG.md"
$handoffPath = Join-Path $root "HANDOFF.md"

function Get-ContentSafe([string]$path) {
  if (Test-Path $path) { return Get-Content -Path $path -Raw }
  return ""
}

function Update-ProjectStateDate([string]$path) {
  $dateStamp = (Get-Date).ToString("yyyy-MM-dd")
  if (-not (Test-Path $path)) {
    @(
      "# Huntech Project State",
      "Date: $dateStamp",
      "",
      "## Current Goal",
      "(fill in)",
      "",
      "## UI Decisions",
      "-",
      "",
      "## Done",
      "-",
      "",
      "## In Progress",
      "-",
      "",
      "## Next",
      "-"
    ) | Set-Content -Path $path -Encoding UTF8
    return
  }

  # Ensure we always have an array of lines (even if the file has a single line),
  # because StrictMode will throw if we call .Count on a scalar string.
  $lines = @(Get-Content -Path $path)
  $updated = $false
  for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "^Date:\s*") {
      $lines[$i] = "Date: $dateStamp"
      $updated = $true
      break
    }
  }
  if (-not $updated) {
    $lines = @("Date: $dateStamp") + $lines
  }
  $lines | Set-Content -Path $path -Encoding UTF8
}

Update-ProjectStateDate $statePath

$gitInfo = ""
try {
  $isGit = git rev-parse --is-inside-work-tree 2>$null
  if ($LASTEXITCODE -eq 0 -and $isGit -eq "true") {
    $head = git rev-parse --short HEAD 2>$null
    $statusText = (git status --short 2>$null | Out-String).TrimEnd()
    $diffText = (git diff --stat 2>$null | Out-String).TrimEnd()
    $gitInfo = @"
## Git
- Head: $head
- Status:
```
$statusText
```
- Diff Stat:
```
$diffText
```
"@
    $gitInfo = $gitInfo.TrimEnd()
  }
} catch {
  $gitInfo = ""
}

$state = Get-ContentSafe $statePath
$tasks = Get-ContentSafe $tasksPath
$changelog = Get-ContentSafe $changelogPath

$handoff = @(
  "# Huntech Handoff",
  "Generated: $((Get-Date).ToString("yyyy-MM-dd HH:mm"))",
  "",
  "## Project State",
  ($state.TrimEnd()),
  "",
  "## Tasks",
  ($tasks.TrimEnd()),
  "",
  "## Changelog",
  ($changelog.TrimEnd())
) -join "`n"

if ($gitInfo) {
  $handoff += "`n`n" + $gitInfo
}

$handoff | Set-Content -Path $handoffPath -Encoding UTF8

Write-Output "Handoff generated at $handoffPath"

# Huntech AWS Deployment Script (PowerShell)
# Run this from the project root directory

param(
    [string]$AppName = "huntech",
    [string]$EnvName = "huntech-prod",
    [string]$Region = "us-east-1",
    [string]$AccountId = "382773571217"
)

Set-StrictMode -Version Latest

$ErrorActionPreference = "Stop"

Write-Host "=== Huntech AWS Deployment ===" -ForegroundColor Cyan
Write-Host "App: $AppName"
Write-Host "Environment: $EnvName"
Write-Host "Region: $Region"
Write-Host "Account: $AccountId"
Write-Host ""

$S3Bucket = "$AppName-eb-$AccountId"
$projectRoot = Get-Location
$versionLabel = "v1-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
$s3Key = "huntech-$versionLabel.zip"
$zipFile = "$env:TEMP\huntech-$versionLabel.zip"
$optionSettings = "Namespace=aws:elasticbeanstalk:application:environment,OptionName=NODE_ENV,Value=production"
$sourceBundle = "S3Bucket=$S3Bucket,S3Key=$s3Key"

function Test-AwsCli {
    try {
        $version = aws --version 2>$null
        Write-Host "OK: AWS CLI found: $version" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "ERR: AWS CLI not found. Install from: https://aws.amazon.com/cli/" -ForegroundColor Red
        return $false
    }
}

function Test-AwsCredentials {
    try {
        $identity = aws sts get-caller-identity --region $Region 2>$null | ConvertFrom-Json
        Write-Host "OK: AWS credentials valid. Using account: $($identity.Account)" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "ERR: AWS credentials not configured. Run: aws configure" -ForegroundColor Red
        return $false
    }
}

Write-Host "[1/7] Validating prerequisites..." -ForegroundColor Yellow
if (-not (Test-AwsCli)) { exit 1 }
if (-not (Test-AwsCredentials)) { exit 1 }

Write-Host "[2/7] Creating S3 bucket..." -ForegroundColor Yellow
try {
    aws s3 mb "s3://$S3Bucket" --region $Region 2>$null | Out-Null
    Write-Host "OK: S3 bucket ready: $S3Bucket" -ForegroundColor Green
} catch {
    Write-Host "OK: S3 bucket already exists" -ForegroundColor Green
}

Write-Host "[3/7] Creating Elastic Beanstalk application..." -ForegroundColor Yellow
try {
    aws elasticbeanstalk create-application --application-name $AppName --region $Region 2>$null | Out-Null
    Write-Host "OK: Application created or already exists" -ForegroundColor Green
} catch {
    Write-Host "OK: Application already exists" -ForegroundColor Green
}

Write-Host "[4/7] Creating Elastic Beanstalk environment (this takes 3-5 minutes)..." -ForegroundColor Yellow
try {
    aws elasticbeanstalk create-environment `
        --application-name $AppName `
        --environment-name $EnvName `
        --solution-stack-name "64bit Amazon Linux 2 v5.8.3 running Node.js 18" `
        --instance-type "t3.micro" `
        --region $Region `
        --option-settings $optionSettings `
        2>$null | Out-Null
    Write-Host "OK: Environment creation started" -ForegroundColor Green
} catch {
    Write-Host "OK: Environment already exists or in progress" -ForegroundColor Green
}

Write-Host "[5/7] Waiting for environment to be ready..." -ForegroundColor Yellow
try {
    aws elasticbeanstalk wait environment-ready `
        --application-name $AppName `
        --environment-names $EnvName `
        --region $Region 2>$null | Out-Null
    Write-Host "OK: Environment is ready" -ForegroundColor Green
} catch {
    Write-Host "WARN: Environment may still be initializing" -ForegroundColor Yellow
}

Write-Host "[6/7] Getting environment details..." -ForegroundColor Yellow
$cname = $null
try {
    $cname = aws elasticbeanstalk describe-environments `
        --application-name $AppName `
        --environment-names $EnvName `
        --region $Region `
        --query 'Environments[0].CNAME' `
        --output text 2>$null
    if ($cname -and $cname -ne "None") {
        Write-Host "OK: Environment URL: $cname" -ForegroundColor Green
    }
} catch {
    Write-Host "WARN: Could not retrieve URL yet" -ForegroundColor Yellow
}

Write-Host "[7/7] Preparing and uploading files..." -ForegroundColor Yellow
try {
    Write-Host "  Creating ZIP package..." -ForegroundColor Cyan
    if (Get-Command Compress-Archive -ErrorAction SilentlyContinue) {
        Compress-Archive -Path "$projectRoot\*" -DestinationPath $zipFile -Force
    } else {
        Write-Host "ERR: Compress-Archive not found" -ForegroundColor Red
        exit 1
    }

    if (Test-Path $zipFile) {
        $zipSize = (Get-Item $zipFile).Length / 1MB
        Write-Host "  ZIP created: $(Split-Path $zipFile -Leaf) ($([Math]::Round($zipSize, 2)) MB)" -ForegroundColor Cyan

        Write-Host "  Uploading to S3..." -ForegroundColor Cyan
        aws s3 cp $zipFile "s3://$S3Bucket/$s3Key" --region $Region | Out-Null
        Write-Host "OK: Files uploaded to S3" -ForegroundColor Green

        Write-Host "  Creating EB application version..." -ForegroundColor Cyan
        aws elasticbeanstalk create-application-version `
            --application-name $AppName `
            --version-label $versionLabel `
            --source-bundle $sourceBundle `
            --region $Region | Out-Null

        Write-Host "  Updating EB environment..." -ForegroundColor Cyan
        aws elasticbeanstalk update-environment `
            --application-name $AppName `
            --environment-name $EnvName `
            --version-label $versionLabel `
            --region $Region | Out-Null
        Write-Host "OK: Environment update started" -ForegroundColor Green

        Remove-Item $zipFile -Force
    } else {
        Write-Host "ERR: Failed to create ZIP file" -ForegroundColor Red
    }
} catch {
    Write-Host "ERR: Upload failed: $_" -ForegroundColor Red
    Write-Host "  You can upload manually from CloudShell" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=== Deployment Status ===" -ForegroundColor Cyan
Write-Host ""
if ($cname -and $cname -ne "None") {
    Write-Host "Your app will be available at:" -ForegroundColor Cyan
    Write-Host "  http://$cname" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Test on your iPhone with this link:" -ForegroundColor Cyan
    Write-Host "  http://$cname" -ForegroundColor Yellow
} else {
    Write-Host "Once environment completes (1-5 mins), get your URL:" -ForegroundColor Cyan
    Write-Host "  aws elasticbeanstalk describe-environments --application-name $AppName --region $Region --query 'Environments[0].CNAME' --output text" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "To check deployment logs:" -ForegroundColor Cyan
Write-Host "  aws elasticbeanstalk request-environment-info --application-name $AppName --environment-name $EnvName --info-type tail --region $Region" -ForegroundColor Yellow
Write-Host ""
Write-Host "To stop the environment (save costs):" -ForegroundColor Cyan
Write-Host "  aws elasticbeanstalk terminate-environment --application-name $AppName --environment-name $EnvName --region $Region" -ForegroundColor Yellow

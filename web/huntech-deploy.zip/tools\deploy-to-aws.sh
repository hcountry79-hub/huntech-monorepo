#!/bin/bash
set -e

echo "=== Huntech AWS Deployment ==="
echo "Region: us-east-1"
echo "Account: 382773571217"
echo ""

# Variables
APP_NAME="huntech"
ENV_NAME="huntech-prod"
REGION="us-east-1"
ACCOUNT_ID="382773571217"

echo "[1/6] Creating S3 bucket for deployment packages..."
S3_BUCKET="${APP_NAME}-eb-${ACCOUNT_ID}"
aws s3 mb "s3://${S3_BUCKET}" --region ${REGION} 2>/dev/null || echo "Bucket already exists"

echo "[2/6] Initializing Elastic Beanstalk application..."
aws elasticbeanstalk create-application \
  --application-name ${APP_NAME} \
  --region ${REGION} 2>/dev/null || echo "Application already exists"

echo "[3/6] Creating Elastic Beanstalk environment..."
aws elasticbeanstalk create-environment \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --solution-stack-name "64bit Amazon Linux 2 v5.8.3 running Node.js 18" \
  --instance-type "t3.micro" \
  --region ${REGION} \
  --option-settings \
    Namespace=aws:autoscaling:launchconfiguration,OptionName=IamInstanceProfile,Value=aws-elasticbeanstalk-ec2-role \
    Namespace=aws:elasticbeanstalk:application:environment,OptionName=NODE_ENV,Value=production \
    Namespace=aws:elasticbeanstalk:cloudwatch:logs,OptionName=StreamLogs,Value=true \
  2>/dev/null || echo "Environment already exists or creation in progress"

echo "[4/6] Waiting for environment to be ready (this may take 3-5 minutes)..."
aws elasticbeanstalk wait environment-ready \
  --application-name ${APP_NAME} \
  --environment-names ${ENV_NAME} \
  --region ${REGION} 2>/dev/null || echo "Environment check completed"

echo "[5/6] Getting environment details..."
ENV_URL=$(aws elasticbeanstalk describe-environments \
  --application-name ${APP_NAME} \
  --environment-names ${ENV_NAME} \
  --region ${REGION} \
  --query 'Environments[0].CNAME' \
  --output text 2>/dev/null || echo "pending")

echo "[6/6] Creating security group rule to allow port 8080..."
# Get the security group from the environment
SG_ID=$(aws elasticbeanstalk describe-environment-resources \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --region ${REGION} \
  --query 'EnvironmentResources.Instances[0].SecurityGroups[0]' \
  --output text 2>/dev/null || echo "")

if [ ! -z "$SG_ID" ] && [ "$SG_ID" != "None" ]; then
  aws ec2 authorize-security-group-ingress \
    --group-id "$SG_ID" \
    --protocol tcp \
    --port 8080 \
    --cidr 0.0.0.0/0 \
    --region ${REGION} 2>/dev/null || echo "Security group rule already exists"
fi

echo ""
echo "=== Deployment Setup Complete ==="
echo ""
echo "Your app will be available at:"
echo "  http://${ENV_URL}:8080"
echo ""
echo "Next steps:"
echo "1. Upload your Huntech files to this S3 bucket:"
echo "   s3://${S3_BUCKET}"
echo ""
echo "2. Test the deployment URL above (may take a few more minutes to fully initialize)"
echo ""
echo "3. Once files are uploaded, you'll see your Huntech app running"
echo ""
echo "To check environment status:"
echo "  aws elasticbeanstalk describe-environments --application-name ${APP_NAME} --region ${REGION}"

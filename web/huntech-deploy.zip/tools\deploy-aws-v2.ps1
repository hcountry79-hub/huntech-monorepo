#!/usr/bin/env powershell
# Huntech AWS Deployment Script

param(
    [string]$AppName = "huntech",
    [string]$EnvName = "huntech-prod",
    [string]$Region = "us-east-1",
    [string]$AccountId = "382773571217"
)

$ErrorActionPreference = "SilentlyContinue"

Write-Host "================================" -ForegroundColor Cyan
Write-Host "HUNTECH AWS DEPLOYMENT" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "App Name: $AppName" -ForegroundColor Yellow
Write-Host "Environment: $EnvName" -ForegroundColor Yellow
Write-Host "Region: $Region" -ForegroundColor Yellow
Write-Host "Account: $AccountId" -ForegroundColor Yellow
Write-Host ""

$S3Bucket = "$AppName-eb-$AccountId"

# Check AWS CLI
Write-Host "[1/6] Checking AWS CLI..." -ForegroundColor Cyan
$awsVersion = aws --version 2>$null
if ($awsVersion) {
    Write-Host "✓ AWS CLI found: $awsVersion" -ForegroundColor Green
}
else {
    Write-Host "✗ AWS CLI not found" -ForegroundColor Red
    Write-Host "  Install: https://aws.amazon.com/cli/" -ForegroundColor Yellow
    exit 1
}

# Check credentials
Write-Host "[2/6] Checking AWS credentials..." -ForegroundColor Cyan
$identity = aws sts get-caller-identity --region $Region 2>$null
if ($identity) {
    Write-Host "✓ AWS credentials valid" -ForegroundColor Green
}
else {
    Write-Host "✗ AWS credentials not configured" -ForegroundColor Red
    Write-Host "  Run: aws configure" -ForegroundColor Yellow
    exit 1
}

# Create S3 bucket
Write-Host "[3/6] Creating S3 bucket..." -ForegroundColor Cyan
aws s3 mb "s3://$S3Bucket" --region $Region 2>$null
Write-Host "✓ S3 bucket ready: $S3Bucket" -ForegroundColor Green

# Create Elastic Beanstalk application
Write-Host "[4/6] Creating Elastic Beanstalk application..." -ForegroundColor Cyan
aws elasticbeanstalk create-application `
    --application-name $AppName `
    --region $Region 2>$null
Write-Host "✓ Application created/ready" -ForegroundColor Green

# Create environment
Write-Host "[5/6] Creating Elastic Beanstalk environment..." -ForegroundColor Cyan
Write-Host "  (This will take 3-5 minutes...)" -ForegroundColor Yellow

aws elasticbeanstalk create-environment `
    --application-name $AppName `
    --environment-name $EnvName `
    --solution-stack-name "64bit Amazon Linux 2 v5.8.3 running Node.js 18" `
    --instance-type "t3.micro" `
    --region $Region 2>$null

Write-Host "✓ Environment setup started" -ForegroundColor Green

# Wait for environment
Write-Host "[6/6] Waiting for environment to be ready..." -ForegroundColor Cyan
$attempts = 0
$maxAttempts = 60

while ($attempts -lt $maxAttempts) {
    $envStatus = aws elasticbeanstalk describe-environments `
        --application-name $AppName `
        --environment-names $EnvName `
        --region $Region `
        --query 'Environments[0].[Status,HealthStatus,CNAME]' `
        --output text 2>$null
    
    if ($envStatus) {
        $parts = $envStatus -split '\s+'
        if ($parts.Count -ge 2) {
            $status = $parts[0]
            $health = $parts[1]
            Write-Host "  Status: $status | Health: $health" -ForegroundColor Cyan
            
            if ($status -eq "Ready" -and $health -eq "Green") {
                Write-Host "✓ Environment is ready!" -ForegroundColor Green
                $cname = $parts[2]
                break
            }
        }
    }
    
    Start-Sleep -Seconds 10
    $attempts++
}

# Get the final URL
if (-not $cname) {
    $cname = aws elasticbeanstalk describe-environments `
        --application-name $AppName `
        --environment-names $EnvName `
        --region $Region `
        --query 'Environments[0].CNAME' `
        --output text 2>$null
}

Write-Host ""
Write-Host "================================" -ForegroundColor Green
Write-Host "DEPLOYMENT COMPLETE!" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""

if ($cname -and $cname -ne "None") {
    Write-Host "Your Huntech app URL:" -ForegroundColor Cyan
    Write-Host "  http://$cname" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Test on iPhone:" -ForegroundColor Cyan
    Write-Host "  Open browser and go to: http://$cname" -ForegroundColor Yellow
}
else {
    Write-Host "Environment is being initialized..." -ForegroundColor Yellow
    Write-Host "Check status with:" -ForegroundColor Cyan
    Write-Host "  aws elasticbeanstalk describe-environments --application-name $AppName --region $Region" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "To stop (save costs):" -ForegroundColor Cyan
Write-Host "  aws elasticbeanstalk terminate-environment --application-name $AppName --environment-name $EnvName --region $Region" -ForegroundColor Yellow
Write-Host ""

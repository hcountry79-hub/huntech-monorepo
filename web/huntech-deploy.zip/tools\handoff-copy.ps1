Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = $MyInvocation.MyCommand.Path
$toolsDir = Split-Path -Parent $scriptPath
$root = Split-Path -Parent $toolsDir
$handoffPath = Join-Path $root "HANDOFF.md"

if (-not (Test-Path $handoffPath)) {
  Write-Output "HANDOFF.md not found. Generating now..."
  try {
    powershell -ExecutionPolicy Bypass -File (Join-Path $toolsDir "handoff.ps1") | Out-Null
  } catch {
    Write-Output "Failed to generate HANDOFF.md: $($_.Exception.Message)"
    exit 1
  }
}

try {
  Get-Content -Path $handoffPath -Raw | Set-Clipboard
  Write-Output "HANDOFF.md copied to clipboard. Paste into the new chat."
} catch {
  Write-Output "Clipboard copy failed: $($_.Exception.Message)"
  Write-Output "You can open HANDOFF.md and copy manually."
  exit 1
}

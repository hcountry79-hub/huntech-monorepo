#!/usr/bin/env python3
import boto3
import sys
import time

APP_NAME = "huntech"
ENV_NAME = "huntech-prod"
REGION = "us-east-1"
ACCOUNT_ID = "382773571217"
S3_BUCKET = f"{APP_NAME}-eb-{ACCOUNT_ID}"

print("=" * 40)
print("HUNTECH AWS DEPLOYMENT")
print("=" * 40)
print()

try:
    # Initialize AWS clients
    s3 = boto3.client('s3', region_name=REGION)
    eb = boto3.client('elasticbeanstalk', region_name=REGION)
    
    print("[1/5] Creating S3 bucket...")
    try:
        s3.create_bucket(Bucket=S3_BUCKET)
        print(f"✓ S3 bucket created: {S3_BUCKET}")
    except:
        print(f"✓ S3 bucket already exists: {S3_BUCKET}")
    
    print()
    print("[2/5] Creating Elastic Beanstalk application...")
    try:
        eb.create_application(ApplicationName=APP_NAME)
        print(f"✓ Application created: {APP_NAME}")
    except:
        print(f"✓ Application already exists: {APP_NAME}")
    
    print()
    print("[3/5] Creating Elastic Beanstalk environment...")
    print("(This takes 3-5 minutes...)")
    try:
        eb.create_environment(
            ApplicationName=APP_NAME,
            EnvironmentName=ENV_NAME,
            SolutionStackName="64bit Amazon Linux 2 v5.8.3 running Node.js 18",
            InstanceType="t3.micro",
            OptionSettings=[
                {
                    'Namespace': 'aws:elasticbeanstalk:application:environment',
                    'OptionName': 'NODE_ENV',
                    'Value': 'production'
                }
            ]
        )
        print(f"✓ Environment creation started: {ENV_NAME}")
    except Exception as e:
        if 'EnvironmentAlreadyExistsException' in str(e):
            print(f"✓ Environment already exists: {ENV_NAME}")
        else:
            print(f"⚠ {str(e)}")
    
    print()
    print("[4/5] Waiting for environment to be ready...")
    
    attempts = 0
    while attempts < 60:
        try:
            response = eb.describe_environments(
                ApplicationName=APP_NAME,
                EnvironmentNames=[ENV_NAME]
            )
            
            if response['Environments']:
                env = response['Environments'][0]
                status = env.get('Status')
                health = env.get('HealthStatus')
                cname = env.get('CNAME')
                
                print(f"  Status: {status} | Health: {health}")
                
                if status == 'Ready' and health == 'Green':
                    print("✓ Environment is ready!")
                    break
        except Exception as e:
            print(f"  Checking... ({attempts}/60)")
        
        time.sleep(10)
        attempts += 1
    
    print()
    print("[5/5] Getting your app URL...")
    
    response = eb.describe_environments(
        ApplicationName=APP_NAME,
        EnvironmentNames=[ENV_NAME]
    )
    
    cname = None
    if response['Environments']:
        cname = response['Environments'][0].get('CNAME')
    
    print()
    print("=" * 40)
    print("✓ DEPLOYMENT COMPLETE!")
    print("=" * 40)
    print()
    
    if cname:
        print(f"Your Huntech app is at:")
        print(f"  http://{cname}")
        print()
        print(f"Test on iPhone:")
        print(f"  http://{cname}")
    else:
        print(f"Environment is being initialized...")
        print(f"Check status with:")
        print(f"  aws elasticbeanstalk describe-environments --application-name {APP_NAME} --region {REGION}")
    
    print()
    print(f"To stop (save costs):")
    print(f"  aws elasticbeanstalk terminate-environment --application-name {APP_NAME} --environment-name {ENV_NAME} --region {REGION}")
    print()

except Exception as e:
    print(f"✗ Error: {str(e)}")
    sys.exit(1)

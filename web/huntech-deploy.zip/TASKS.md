# Tasks
- [ ] Polish Plan + Route panel layout
- [ ] Improve scouting layer visuals
- [ ] Add pressure heatmap overlay
- [ ] Add stealth access route overlay
- [ ] Add terrain/elevation scoring

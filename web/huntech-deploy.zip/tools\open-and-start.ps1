$projectPath = Split-Path -Parent $PSScriptRoot

$codeExe = Get-Command code -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source
if (-not $codeExe) {
    $candidatePaths = @(
        "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe",
        "$env:PROGRAMFILES\Microsoft VS Code\Code.exe",
        "$env:PROGRAMFILES(x86)\Microsoft VS Code\Code.exe"
    )
    $codeExe = $candidatePaths | Where-Object { Test-Path $_ } | Select-Object -First 1
}

if (-not $codeExe) {
    Write-Host "VS Code not found in PATH or default install locations."
    Write-Host "Open VS Code manually, then File -> Open Folder -> $projectPath"
    exit 1
}

Start-Process -FilePath $codeExe -ArgumentList @("-r", $projectPath)
Write-Host "VS Code opened. Auto-start tasks will run on folder open."

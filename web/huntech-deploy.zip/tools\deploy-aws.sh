#!/bin/bash

APP_NAME="huntech"
ENV_NAME="huntech-prod"
REGION="us-east-1"
ACCOUNT_ID="382773571217"
S3_BUCKET="${APP_NAME}-eb-${ACCOUNT_ID}"

echo "================================"
echo "HUNTECH AWS DEPLOYMENT"
echo "================================"
echo ""
echo "Checking AWS CLI..."

if ! command -v aws &> /dev/null; then
    echo "✗ AWS CLI not found"
    exit 1
fi

echo "✓ AWS CLI found"
echo ""
echo "[1/5] Creating S3 bucket..."
aws s3 mb "s3://${S3_BUCKET}" --region ${REGION} 2>/dev/null || echo "Bucket already exists"
echo "✓ S3 bucket ready: ${S3_BUCKET}"

echo ""
echo "[2/5] Creating Elastic Beanstalk application..."
aws elasticbeanstalk create-application \
    --application-name ${APP_NAME} \
    --region ${REGION} 2>/dev/null || echo "Application already exists"
echo "✓ Application ready"

echo ""
echo "[3/5] Creating Elastic Beanstalk environment..."
echo "(This takes 3-5 minutes...)"
aws elasticbeanstalk create-environment \
    --application-name ${APP_NAME} \
    --environment-name ${ENV_NAME} \
    --solution-stack-name "64bit Amazon Linux 2 v5.8.3 running Node.js 18" \
    --instance-type "t3.micro" \
    --region ${REGION} 2>/dev/null || echo "Environment already exists"
echo "✓ Environment creation started"

echo ""
echo "[4/5] Waiting for environment to be ready..."
ATTEMPTS=0
while [ $ATTEMPTS -lt 60 ]; do
    STATUS=$(aws elasticbeanstalk describe-environments \
        --application-name ${APP_NAME} \
        --environment-names ${ENV_NAME} \
        --region ${REGION} \
        --query 'Environments[0].[Status,HealthStatus]' \
        --output text 2>/dev/null)
    
    if [[ $STATUS == *"Ready"* ]] && [[ $STATUS == *"Green"* ]]; then
        echo "✓ Environment is ready!"
        break
    fi
    
    echo "  Waiting... ($ATTEMPTS/60)"
    sleep 10
    ATTEMPTS=$((ATTEMPTS+1))
done

echo ""
echo "[5/5] Getting your app URL..."
CNAME=$(aws elasticbeanstalk describe-environments \
    --application-name ${APP_NAME} \
    --environment-names ${ENV_NAME} \
    --region ${REGION} \
    --query 'Environments[0].CNAME' \
    --output text 2>/dev/null)

echo ""
echo "================================"
echo "✓ DEPLOYMENT COMPLETE!"
echo "================================"
echo ""

if [ ! -z "$CNAME" ] && [ "$CNAME" != "None" ]; then
    echo "Your Huntech app is at:"
    echo "  http://${CNAME}"
    echo ""
    echo "Test on iPhone:"
    echo "  Open Safari/Chrome and go to: http://${CNAME}"
else
    echo "Environment is initializing..."
    echo "Check status with:"
    echo "  aws elasticbeanstalk describe-environments --application-name ${APP_NAME} --region ${REGION}"
fi

echo ""
echo "To stop (save costs):"
echo "  aws elasticbeanstalk terminate-environment --application-name ${APP_NAME} --environment-name ${ENV_NAME} --region ${REGION}"
echo ""

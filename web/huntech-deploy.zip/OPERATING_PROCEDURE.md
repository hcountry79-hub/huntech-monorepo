# Huntech Operating Procedure

## Goal
Run everything with one command and always have a fresh handoff ready for a new chat.

## One-command startup (recommended)
Use the VS Code task:
- Open the Command Palette.
- Run Task: Huntech: Start Everything

## One-click startup (desktop friendly)
Double-click:
- Start-Huntech.cmd

This opens the project in VS Code and the auto-start tasks run on folder open.

This will:
- Start the dev server (http://localhost:8080).
- Start the auto handoff watcher.
- Generate HANDOFF.md and copy it to your clipboard.
- Open the app in your browser.

## Daily flow
- Make code changes as usual.
- On every save, HANDOFF.md updates and is copied to clipboard.
- When a chat locks up, open a new chat and paste from clipboard.

## Crash recovery (full automation)
Use this when your PC or VS Code crashes and you want to get back to the last working point fast.

### Step-by-step recovery
1. Reopen VS Code.
2. Open the project folder:
	- File -> Open Folder -> Desktop -> Huntech -> base code -> BASE CODE
3. Run the master task:
	- Command Palette -> Run Task -> Huntech: Start Everything
4. Wait 5-10 seconds for the app and watcher to start.
5. If a new chat is needed, paste from clipboard (the latest handoff is already copied).

### What the master task does
- Starts the dev server at http://localhost:8080/
- Starts the auto handoff watcher
- Regenerates HANDOFF.md
- Copies HANDOFF.md to the clipboard
- Opens the app in your browser

### If the app does not open after a crash
Run the task:
- Huntech: Open App

### If the server did not start
Run the task:
- Huntech: Start Dev Server

### If the handoff is stale
Run these tasks in order:
- Huntech: Generate Handoff
- Huntech: Copy Handoff to Clipboard

## If the app does not open
- Run Task: Huntech: Open App

## If the server is not running
- Run Task: Huntech: Start Dev Server

## If the handoff did not update
- Run Task: Huntech: Generate Handoff
- Then run Task: Huntech: Copy Handoff to Clipboard

## Where files live
- Handoff summary: HANDOFF.md
- Project state: PROJECT_STATE.md
- Backups (chat + files): backups/

## Notes
- Auto startup on folder open is enabled for the dev server and handoff watcher.
- The proxy endpoint is /proxy?url= for mdc.mo.gov requests.

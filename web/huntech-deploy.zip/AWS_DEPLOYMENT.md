# AWS Deployment Guide for Huntech

## Prerequisites
- AWS Account: 382773571217
- Region: us-east-1
- All app files ready for upload

## Step-by-Step Deployment

### Step 1: Set Up Variables
Run this in CloudShell:
```bash
APP_NAME="huntech"
ENV_NAME="huntech-prod"
REGION="us-east-1"
ACCOUNT_ID="382773571217"
S3_BUCKET="${APP_NAME}-eb-${ACCOUNT_ID}"
echo "Deploying to: $S3_BUCKET"
```

### Step 2: Create S3 Bucket
```bash
aws s3 mb "s3://${S3_BUCKET}" --region ${REGION} 2>/dev/null && echo "Bucket created" || echo "Bucket already exists"
```

### Step 3: Create Elastic Beanstalk Application
```bash
aws elasticbeanstalk create-application \
  --application-name ${APP_NAME} \
  --region ${REGION} 2>/dev/null && echo "Application created" || echo "Application already exists"
```

### Step 4: Create Elastic Beanstalk Environment
```bash
aws elasticbeanstalk create-environment \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --solution-stack-name "64bit Amazon Linux 2 v5.8.3 running Node.js 18" \
  --instance-type "t3.micro" \
  --region ${REGION}
```

This will take 3-5 minutes. Monitor progress with:
```bash
watch -n 10 'aws elasticbeanstalk describe-environments --application-name ${APP_NAME} --region ${REGION} --query "Environments[0].[EnvironmentName,Status,HealthStatus]" --output table'
```

(Press Ctrl+C when status shows "Ready" and "Green")

### Step 5: Get Your Environment URL
Once environment is ready, run:
```bash
aws elasticbeanstalk describe-environments \
  --application-name ${APP_NAME} \
  --environment-names ${ENV_NAME} \
  --region ${REGION} \
  --query 'Environments[0].CNAME' \
  --output text
```

Save this URL - it will be in format: `huntech-prod.xxxxxx.us-east-1.elasticbeanstalk.com`

### Step 6: Upload Your App Files
In CloudShell, upload your files:
```bash
# Create a temporary directory
mkdir -p /tmp/huntech
cd /tmp/huntech

# Download from your source or upload via CloudShell UI
# Then upload to S3:
aws s3 cp . "s3://${S3_BUCKET}/huntech-app/" --recursive --region ${REGION}
```

Or use CloudShell's file upload feature to drag/drop your files.

### Step 7: Deploy to Elastic Beanstalk
Create a ZIP of your app (excluding node_modules):
```bash
cd /tmp/huntech
zip -r ../huntech.zip . -x "node_modules/*" ".git/*" "backups/*"

aws elasticbeanstalk create-application-version \
  --application-name ${APP_NAME} \
  --version-label "v1-$(date +%s)" \
  --source-bundle S3Bucket="${S3_BUCKET}",S3Key="huntech.zip" \
  --region ${REGION}

aws elasticbeanstalk update-environment \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --version-label "v1-$(date +%s)" \
  --region ${REGION}
```

### Step 8: Test Your App
Once deployment completes (1-2 minutes), test:
```bash
CNAME=$(aws elasticbeanstalk describe-environments \
  --application-name ${APP_NAME} \
  --environment-names ${ENV_NAME} \
  --region ${REGION} \
  --query 'Environments[0].CNAME' \
  --output text)

echo "Your app is at: http://${CNAME}"
```

### Step 9: Access on iPhone
Open in your mobile browser:
```
http://${CNAME}
```

Replace `${CNAME}` with the actual domain from Step 5.

## Troubleshooting

Check logs:
```bash
aws elasticbeanstalk request-environment-info \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --info-type tail \
  --region ${REGION}

aws elasticbeanstalk retrieve-environment-info \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --info-type tail \
  --region ${REGION}
```

Check environment status:
```bash
aws elasticbeanstalk describe-environments \
  --application-name ${APP_NAME} \
  --region ${REGION} \
  --query 'Environments[0].[EnvironmentName,Status,HealthStatus]' \
  --output table
```

## Cost Management

This uses t3.micro instance (free tier eligible if within 12 months). To stop when not testing:
```bash
aws elasticbeanstalk terminate-environment \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --region ${REGION}
```

To restart later:
```bash
# Re-create the environment (same steps as Step 4)
```

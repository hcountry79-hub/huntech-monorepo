// Auto Chat + File Backup Script for HUNTECH
// Goal: keep Copilot/VS Code chat logs and project files continuously backed up locally
// so nothing gets stranded in frozen chat sessions.

const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = __dirname;
const BACKUP_ROOT = path.join(PROJECT_ROOT, 'backups');
const CHAT_BACKUP_ROOT = path.join(BACKUP_ROOT, 'chat');
const FILE_BACKUP_ROOT = path.join(BACKUP_ROOT, 'files', 'latest');

const CHAT_DIRS = ['chatSessions', 'chatEditingSessions'];
const CODE_VARIANTS = ['Code', 'Code - Insiders'];

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function statSafe(p) {
  try {
    return fs.statSync(p);
  } catch {
    return null;
  }
}

function readTextSafe(filePath, maxBytes = 256 * 1024) {
  try {
    const fd = fs.openSync(filePath, 'r');
    try {
      const buf = Buffer.alloc(maxBytes);
      const bytesRead = fs.readSync(fd, buf, 0, maxBytes, 0);
      return buf.slice(0, bytesRead).toString('utf8');
    } finally {
      fs.closeSync(fd);
    }
  } catch {
    return '';
  }
}

function getWorkspaceStorageRoots() {
  const appdata = process.env.APPDATA;
  if (!appdata) return [];
  const roots = [];
  for (const variant of CODE_VARIANTS) {
    const candidate = path.join(appdata, variant, 'User', 'workspaceStorage');
    if (statSafe(candidate)?.isDirectory()) roots.push(candidate);
  }
  return roots;
}

function getLatestMtimeInDir(dirPath) {
  try {
    const files = fs.readdirSync(dirPath);
    let latest = 0;
    for (const name of files) {
      const st = statSafe(path.join(dirPath, name));
      if (!st || !st.isFile()) continue;
      latest = Math.max(latest, st.mtimeMs || 0);
    }
    return latest;
  } catch {
    return 0;
  }
}

function findChatCandidates(projectRoot) {
  const projectNeedle = String(projectRoot).toLowerCase().replace(/\\/g, '/');
  const roots = getWorkspaceStorageRoots();
  const candidates = [];

  for (const root of roots) {
    let entries = [];
    try {
      entries = fs.readdirSync(root, { withFileTypes: true }).filter((d) => d.isDirectory());
    } catch {
      continue;
    }

    for (const dirent of entries) {
      const storageId = dirent.name;
      const storagePath = path.join(root, storageId);

      const chatPaths = CHAT_DIRS.map((d) => path.join(storagePath, d));
      const hasAnyChat = chatPaths.some((p) => statSafe(p)?.isDirectory());
      if (!hasAnyChat) continue;

      // Try to match this workspaceStorage folder to the current project.
      // Heuristic: search for the project path in likely JSON files.
      const jsonCandidates = ['workspace.json', 'storage.json'];
      let matchesProject = false;
      for (const jsonName of jsonCandidates) {
        const p = path.join(storagePath, jsonName);
        if (!statSafe(p)?.isFile()) continue;
        const text = readTextSafe(p);
        if (text.toLowerCase().replace(/\\/g, '/').includes(projectNeedle)) {
          matchesProject = true;
          break;
        }
      }

      // Activity score: newest file mtime across chat dirs
      const activity = Math.max(...chatPaths.map(getLatestMtimeInDir));
      candidates.push({ root, storageId, storagePath, chatPaths, matchesProject, activity });
    }
  }

  // Prefer matching storage folders; else take the most active few.
  const matched = candidates.filter((c) => c.matchesProject);
  if (matched.length) return matched.sort((a, b) => b.activity - a.activity);
  return candidates.sort((a, b) => b.activity - a.activity).slice(0, 3);
}

function copyIfChanged(src, dest) {
  const srcStat = statSafe(src);
  if (!srcStat || !srcStat.isFile()) return false;

  const destStat = statSafe(dest);
  if (destStat && destStat.isFile()) {
    if ((destStat.size === srcStat.size) && (Math.abs((destStat.mtimeMs || 0) - (srcStat.mtimeMs || 0)) < 1000)) {
      return false;
    }
  }

  ensureDir(path.dirname(dest));
  fs.copyFileSync(src, dest);
  try {
    fs.utimesSync(dest, new Date(srcStat.atimeMs), new Date(srcStat.mtimeMs));
  } catch {
    // best-effort
  }
  return true;
}

function mirrorChatOnce(selected) {
  let copied = 0;
  for (const entry of selected) {
    for (const dirName of CHAT_DIRS) {
      const srcDir = path.join(entry.storagePath, dirName);
      if (!statSafe(srcDir)?.isDirectory()) continue;

      const destDir = path.join(CHAT_BACKUP_ROOT, entry.storageId, dirName);
      ensureDir(destDir);

      let files = [];
      try {
        files = fs.readdirSync(srcDir);
      } catch {
        continue;
      }

      for (const name of files) {
        if (!(name.endsWith('.jsonl') || name.endsWith('.json'))) continue;
        const src = path.join(srcDir, name);
        const dest = path.join(destDir, name);
        if (copyIfChanged(src, dest)) copied++;
      }
    }
  }
  return copied;
}

function mirrorProjectFilesOnce() {
  const allowed = new Set(['.html', '.js', '.css', '.json', '.md', '.txt', '.svg', '.png', '.jpg', '.jpeg']);
  let copied = 0;

  let entries = [];
  try {
    entries = fs.readdirSync(PROJECT_ROOT, { withFileTypes: true });
  } catch {
    return 0;
  }

  for (const e of entries) {
    if (!e.isFile()) continue;
    const name = e.name;
    if (name === 'backups') continue;
    const ext = path.extname(name).toLowerCase();
    if (!allowed.has(ext)) continue;
    const src = path.join(PROJECT_ROOT, name);
    const dest = path.join(FILE_BACKUP_ROOT, name);
    if (copyIfChanged(src, dest)) copied++;
  }

  return copied;
}

function writeManifest(selected) {
  const manifestPath = path.join(BACKUP_ROOT, 'backup-manifest.json');
  const payload = {
    projectRoot: PROJECT_ROOT,
    createdAt: new Date().toISOString(),
    selectedWorkspaceStorage: selected.map((s) => ({
      root: s.root,
      storageId: s.storageId,
      matchesProject: s.matchesProject,
      activity: s.activity
    }))
  };
  ensureDir(BACKUP_ROOT);
  fs.writeFileSync(manifestPath, JSON.stringify(payload, null, 2));
}

function main() {
  ensureDir(CHAT_BACKUP_ROOT);
  ensureDir(FILE_BACKUP_ROOT);

  const selected = findChatCandidates(PROJECT_ROOT);
  writeManifest(selected);

  console.log('HUNTECH Auto Backup running.');
  console.log('Backups folder:', BACKUP_ROOT);
  if (!selected.length) {
    console.log('No VS Code chat storage folders found yet. (This is OK if no chats exist on this machine.)');
  } else {
    console.log('Selected workspaceStorage folders:', selected.map((s) => s.storageId).join(', '));
  }

  const sync = () => {
    const c1 = mirrorChatOnce(selected);
    const c2 = mirrorProjectFilesOnce();
    if (c1 || c2) {
      console.log(`[${new Date().toLocaleTimeString()}] Backed up: chats=${c1}, files=${c2}`);
    }
  };

  sync();
  setInterval(sync, 25_000);
}

main();

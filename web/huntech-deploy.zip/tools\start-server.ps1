Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = $MyInvocation.MyCommand.Path
$toolsDir = Split-Path -Parent $scriptPath
$root = Split-Path -Parent $toolsDir

$port = 8080
$serverScript = Join-Path $root "server.js"

function Is-PortOpen([int]$p) {
  try {
    return (Test-NetConnection -ComputerName "localhost" -Port $p -InformationLevel Quiet)
  } catch {
    return $false
  }
}

if (-not (Test-Path $serverScript)) {
  Write-Error "server.js not found."
  exit 1
}

if (Is-PortOpen $port) {
  Write-Output "Dev server already running on port $port."
  while ($true) { Start-Sleep -Seconds 5 }
}

Write-Output "Starting dev server on port $port..."
node $serverScript

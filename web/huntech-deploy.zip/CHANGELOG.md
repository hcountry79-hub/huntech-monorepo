## 2026-02-05
- Simplified Field Command tray
- Added Plan + Route popup with criteria, scouting, journal, saved plans
- Added core buck zones for in-depth scouting
- Added saved hunt areas/pins and saved plan persistence
- Added map-level buttons for Field Command and Clear All


export default function Home(){
  return (
    <main style={{background:'#3b2f2f',color:'#ffd54a',minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
      <h1 style={{letterSpacing:'0.06em'}}>HUNTΞCH</h1>
      <p>Where Innovation Meets Tradition.</p>
      <p>Dev shell is alive. Add Mapbox with your token next.</p>
    </main>
  )
}
